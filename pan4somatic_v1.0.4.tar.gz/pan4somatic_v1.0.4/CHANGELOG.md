# v1.0.4

- Fix NGS and HiFi paired FASTQ routing: combine read tuples with their graph by pair ID, reusing the graph for both samples.
- Require explicit resource paths; remove private-server defaults, deployment scripts, interval presets and SIF autodiscovery. No compatibility aliases are provided.
- Remove retries that repeated a failed task with unchanged resources, and the hardcoded Slurm queue.
- Replace string-presence assertions with real Nextflow workflow routing tests using mocked tool bodies. Keep shell/JSON syntax checks.
- Correct the launcher BAM guidance and document the validation boundary.

The routing tests use mocked tool bodies. A fresh real-data server acceptance run is still required before public release.
