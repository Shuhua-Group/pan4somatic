# pan4somatic v1.0.4

The graph/read routing and configuration have automated Nextflow tests. Bioinformatics tool bodies are mocked in those tests; the supplied HG002 results document earlier server execution, while this cleaned package still requires a fresh real-data acceptance run before publication outside the internal review group.

## Run

Requires Linux, Nextflow (tested with 24.10.6), a compatible Java runtime, and the tool environments. With `-profile standard,singularity`, pass `--sif_dir` containing:

- `vg_1.75.1.sif`, `kmc.sif`, `samtools.sif`
- `gatk_4.7.0.0.sif` for NGS
- `deepsomatic_1.10.0.sif` for HiFi SNV/Indel
- `sniffles2_2.8.0.sif` for HiFi SV

Only images used by the chosen run are required. Individual `--container_*` parameters override these filenames. Configure references in `conf/resources.config` or pass the same parameters directly. No server paths, environment-variable resource fallback or automatic data downloads are included.

Paired NGS FASTQ example (replace paths):

```bash
./pan4somatic -profile standard,singularity \
  --entry full --platform ngs --variant_type small \
  --genome grch38 --graph_version hprc1 \
  --analysis_mode tumor_normal \
  --pair_id sample1 --tumor_id sample1_T --normal_id sample1_N \
  --tumor_fastq /data/T_R1.fastq.gz,/data/T_R2.fastq.gz \
  --normal_fastq /data/N_R1.fastq.gz,/data/N_R2.fastq.gz \
  --ref_fasta /data/GRCh38.fa --graph_prefix /data/hprc1/graph \
  --pon /data/pon.vcf.gz --germline /data/germline.vcf.gz \
  --sif_dir /data/containers --outdir results/sample1
```

The normal reads build one personalized graph. Both samples use it. Tumor-only runs use tumor reads instead (`--analysis_mode tumor_only`, omit normal input).

| Choice | Parameters |
|---|---|
| GRCh38/HPRC1 | `--genome grch38 --graph_version hprc1` |
| GRCh38/CPC1+HPRC1 | `--genome grch38 --graph_version cpc1_hprc1` |
| CHM13/CPC2 | `--genome chm13 --graph_version cpc2`; CPC2 graph is unreleased |
| HiFi | `--platform tgs --longread_technology pacbio`; one FASTQ per sample |
| HiFi small variants / SV / both | `--variant_type small`, `sv` or `all` |
| Alignment only | `--entry align_only`; no caller resources required |
| Existing BAM | `--entry call_from_bam --tumor_bam /data/T.bam`; add `--normal_bam` in paired mode; omit FASTQ and graph resources |
| NGS interval restriction | `--interval_bed chr1` or a BED/interval-list path; omit for whole genome |

FASTA requires `.fai` for all runs and a matching `.dict` for NGS calling. PoN and germline VCFs require `.tbi`. BAM inputs must be coordinate-sorted, reference-matched and indexed, with read-group sample names matching `--tumor_id`/`--normal_id`. NGS BAMs should be duplicate-marked; HiFi BAMs are sorted, not duplicate-marked by this workflow.

NGS outputs use Mutect2. HiFi uses DeepSomatic and/or Sniffles2. Paired Sniffles2 produces separate tumor and normal VCF/SNF outputs; it does not perform somatic subtraction. GAM is an intermediate, not a direct entry point. NGS and HiFi run separately.

## Output locations

- NGS BAM: `intermediates/ngs_alignment/<pair_id>/<role>/<sample_id>.dedup.bam` (duplicates marked, not removed).
- HiFi BAM: `intermediates/tgs_alignment/<pair_id>/<role>/<sample_id>.sorted.bam`.
- Caller results: `variants/ngs_mutect2/<pair_id>/`, `variants/tgs_deepsomatic/<pair_id>/`, `variants/tgs_sv_sniffles2/<pair_id>/`.
- QC: `qc/graph/` and `qc/bam/`; execution reports: `pipeline_info/`.

## Tests

```bash
bash tests/static_checks.sh
python3 tests/routing.py
```

Routing tests use the actual main workflow and configuration, replacing tool bodies only inside a temporary copy. They exercise NGS/HiFi × three entries × tumor-only/paired, assert both paired samples reach BAM preflight, check graph-source roles and caller task counts, and verify that BAM entry needs no graph. These tests do not check alignment or variant-call accuracy.

## Deliberate removals

- Removed private-server resource maps/manifests, deployment and toy-data scripts, duplicate configuration templates and obsolete handoff documents.
- Removed `--interval_preset`; pass the actual region/file with `--interval_bed`.
- Removed `PAN4SOMATIC_SIF_DIR` and versioned-directory autodiscovery; pass `--sif_dir` or per-tool paths.
- Removed unchanged-resource retries and the hardcoded Slurm queue. Supply cluster scheduling options in your Nextflow configuration.

Public input/resource links and validation evidence are in the [GitHub documentation](https://github.com/Shuhua-Group/pan4somatic).
