# Source cleanup validation — v1.0.4

Date: 2026-09-24. Runtime: Nextflow 24.10.6, Temurin Java 17, macOS arm64.

## Fixed and removed

Both NGS and HiFi graph/read joins now use `combine(..., by: 0)`. The normal-derived graph is reused for both paired samples.

Removed private server resource paths, deployment/toy scripts, resource registries/templates, interval presets, SIF autodiscovery, fixed Slurm queue and unchanged-resource retries. The package accepts explicit resource paths. No compatibility aliases or wrapper scripts were added.

## Executed tests

Shell/JSON syntax and launcher help/version: PASS.

| Platform | Entry | Tumor-only tasks | Paired tasks | Result |
|---|---|---:|---:|---|
| NGS | full | 8 | 13 | PASS |
| NGS | align_only | 7 | 12 | PASS |
| NGS | call_from_bam | 2 | 3 | PASS |
| HiFi | full | 7 | 11 | PASS |
| HiFi | align_only | 5 | 8 | PASS |
| HiFi | call_from_bam | 3 | 5 | PASS |

These 12 tests execute the actual main workflow and configuration with tool bodies replaced in a temporary copy. They assert process counts, graph source roles and that both paired samples reach BAM preflight. BAM-entry tests omit graph resources.

Negative control: restoring the original `join` made the NGS paired full test fail. Only one alignment/preflight ran and paired Mutect2 did not run (expected two alignment/preflight tasks and one paired Mutect2 task). The tumor-only control still passed. This reproduces the old routing defect without running the bioinformatics tools.

## Limits

No real FASTQ alignment, graph indexing, BAM content validation or caller execution was rerun after the routing correction. HPC/container resource acceptance remains pending. The supplied earlier HG002 evidence is not a fresh validation of this corrected package.

Run `bash tests/static_checks.sh` and `python3 tests/routing.py` from the extracted package to reproduce the automated checks.
