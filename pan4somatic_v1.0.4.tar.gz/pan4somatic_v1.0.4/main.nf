nextflow.enable.dsl = 2

include { COUNT_KMERS; BUILD_PERSONAL_GRAPH } from './modules/personal_graph'
include { NGS_VG_MAP_SURJECT; NGS_SAMTOOLS_NORMALIZE_SORT; NGS_MARK_DUPLICATES; NGS_BAM_INDEX } from './modules/ngs_alignment'
include { TGS_VG_MAP_SURJECT; TGS_SAMTOOLS_NORMALIZE_SORT } from './modules/tgs_alignment'
include { NGS_MUTECT2; NGS_MUTECT2_TUMOR_ONLY } from './modules/ngs_mutect2'
include { TGS_DEEPSOMATIC; TGS_DEEPSOMATIC_TUMOR_ONLY } from './modules/tgs_deepsomatic'
include { TGS_SNIFFLES2; TGS_SNIFFLES2_NORMAL } from './modules/tgs_sniffles'
include { BAM_PREFLIGHT } from './modules/preflight'

def resolveBai(bam) {
    def candidates = ["${bam}.bai", bam.toString().replaceFirst(/\.bam$/, '.bai')].unique()
    def bai = candidates.find { file(it).exists() }
    if (!bai) throw new IllegalArgumentException("Missing BAM index; accepted names: ${candidates.join(' or ')}")
    file(bai, checkIfExists:true)
}

workflow {
    if (!(params.platform in ['ngs','tgs'])) error "--platform must be ngs or tgs"
    if (!(params.entry in ['full','align_only','call_from_bam'])) error "--entry must be full, align_only, or call_from_bam"
    if (!(params.analysis_mode in ['tumor_only','tumor_normal'])) error "--analysis_mode must be tumor_only or tumor_normal"
    if (!(params.variant_type in ['small','sv','all'])) error "--variant_type must be small, sv, or all"
    if (params.platform == 'ngs' && params.variant_type != 'small') error "SV calling is supported for long reads only"
    if (!(params.longread_technology in ['pacbio','ont'])) error "--longread_technology must be pacbio or ont"
    safe_id = ~/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/
    [pair_id:params.pair_id, tumor_id:params.tumor_id, normal_id:params.normal_id].each { name, value ->
        if (!(value ==~ safe_id)) error "--${name} must match ${safe_id}; received '${value}'"
    }
    if (params.tumor_id == params.normal_id && params.analysis_mode == 'tumor_normal') error '--tumor_id and --normal_id must differ'
    if (!(params.kmc_memory_gb instanceof Number) || params.kmc_memory_gb < 1) error '--kmc_memory_gb must be a positive number'
    if (!(params.min_graph_source_coverage instanceof Number) || params.min_graph_source_coverage < 0) error '--min_graph_source_coverage must be non-negative'
    if (params.genome == 'chm13' && params.deepsomatic_use_default_pon_filtering) {
        error '--deepsomatic_use_default_pon_filtering is blocked for CHM13; use a coordinate-matched, explicitly validated filtering strategy'
    }

    if (workflow.profile.contains('singularity')) {
        required_containers = [:]
        required_containers.bam_preflight = params.container_samtools
        if (params.entry != 'call_from_bam') {
            required_containers.kmc = params.container_kmc
            required_containers.vg = params.container_vg
            required_containers.samtools = params.container_samtools
            if (params.platform == 'ngs') required_containers.picard = params.container_picard
        }
        if (params.entry != 'align_only') {
            if (params.platform == 'ngs') required_containers.mutect2 = params.container_mutect2
            if (params.platform == 'tgs' && params.variant_type in ['small','all']) required_containers.deepsomatic = params.container_deepsomatic
            if (params.platform == 'tgs' && params.variant_type in ['sv','all']) required_containers.sniffles2 = params.container_sniffles
        }
        missing_containers = required_containers.findAll { name, image -> !image || !file(image).exists() }
        if (missing_containers) {
            error "Missing required Singularity images:\n  " + missing_containers.collect { name, image -> "${name}: ${image ?: 'not configured'}" }.join('\n  ')
        }
    }

    if (!params.ref_fasta) error '--ref_fasta is required'
    if (!file(params.ref_fasta).exists()) error "Missing reference FASTA: ${params.ref_fasta}"
    if (!file("${params.ref_fasta}.fai").exists()) error "Missing FASTA index: ${params.ref_fasta}.fai"
    ref_dict = params.ref_fasta.replaceFirst(/\.[^.]+$/, '.dict')
    ref_files = [file(params.ref_fasta), file("${params.ref_fasta}.fai")]
    if (params.platform == 'ngs' && params.entry != 'align_only') {
        if (!file(ref_dict).exists()) error "Missing sequence dictionary required by GATK: ${ref_dict}"
        ref_files << file(ref_dict)
    }
    ch_ref = Channel.value(ref_files)
    interval_bed = params.interval_bed ?: ''
    if (interval_bed && (interval_bed.contains('/') || interval_bed ==~ /.*\.(bed|list|interval_list)$/) && !file(interval_bed).exists()) {
        error "Interval file does not exist: ${interval_bed}"
    }
    interval_path = interval_bed && file(interval_bed).exists() ? file(interval_bed, checkIfExists:true) : null
    interval_arg = interval_path ? interval_path.name : interval_bed
    ch_interval = Channel.value([interval_arg, interval_path ? [interval_path] : []])

    if (params.entry == 'call_from_bam') {
        if (!params.tumor_bam) error '--tumor_bam is required for call_from_bam'
        tumor_meta = [pair_id: params.pair_id, sample_id: params.tumor_id, role:'tumor', technology:params.longread_technology]
        ch_all_bam = Channel.of([tumor_meta, file(params.tumor_bam, checkIfExists:true), resolveBai(params.tumor_bam)])
        if (params.analysis_mode == 'tumor_normal') {
            if (!params.normal_bam) error '--normal_bam is required for paired call_from_bam'
            normal_meta = [pair_id:params.pair_id, sample_id:params.normal_id, role:'normal', technology:params.longread_technology]
            ch_all_bam = ch_all_bam.concat(Channel.of([normal_meta, file(params.normal_bam, checkIfExists:true), resolveBai(params.normal_bam)]))
        }
    } else {
        if (!params.graph_prefix) error '--graph_prefix is required for FASTQ input'
        ['gbz','hapl'].each { ext ->
            if (!file("${params.graph_prefix}.${ext}").exists()) error "Missing graph index: ${params.graph_prefix}.${ext}"
        }
        if (!params.tumor_fastq) error '--tumor_fastq is required'
        tumor_meta = [pair_id:params.pair_id, sample_id:params.tumor_id, role:'tumor', technology:params.platform == 'ngs' ? 'illumina' : params.longread_technology]

        if (params.platform == 'ngs') {
            tfq = params.tumor_fastq.tokenize(',')
            if (tfq.size() != 2) error '--tumor_fastq requires comma-separated R1,R2 for ngs'
            ch_reads = Channel.of([tumor_meta, file(tfq[0],checkIfExists:true), file(tfq[1],checkIfExists:true)])
            if (params.analysis_mode == 'tumor_normal') {
                if (!params.normal_fastq) error '--normal_fastq is required in tumor_normal mode'
                nfq = params.normal_fastq.tokenize(',')
                if (nfq.size() != 2) error '--normal_fastq requires comma-separated R1,R2 for ngs'
                normal_meta = [pair_id:params.pair_id, sample_id:params.normal_id, role:'normal', technology:'illumina']
                ch_reads = ch_reads.concat(Channel.of([normal_meta,file(nfq[0],checkIfExists:true),file(nfq[1],checkIfExists:true)]))
                ch_graph_source = Channel.of([normal_meta + [graph_source:'normal'], [file(nfq[0]),file(nfq[1])]])
            } else {
                ch_graph_source = Channel.of([tumor_meta + [graph_source:'tumor'], [file(tfq[0]),file(tfq[1])]])
            }
        } else {
            ch_reads = Channel.of([tumor_meta, file(params.tumor_fastq,checkIfExists:true)])
            if (params.analysis_mode == 'tumor_normal') {
                if (!params.normal_fastq) error '--normal_fastq is required in tumor_normal mode'
                normal_meta = [pair_id:params.pair_id, sample_id:params.normal_id, role:'normal', technology:params.longread_technology]
                ch_reads = ch_reads.concat(Channel.of([normal_meta,file(params.normal_fastq,checkIfExists:true)]))
                ch_graph_source = Channel.of([normal_meta + [graph_source:'normal'], [file(params.normal_fastq)]])
            } else {
                ch_graph_source = Channel.of([tumor_meta + [graph_source:'tumor'], [file(params.tumor_fastq)]])
            }
        }

        COUNT_KMERS(ch_graph_source, file("${params.ref_fasta}.fai"))
        BUILD_PERSONAL_GRAPH(COUNT_KMERS.out.kmers, file("${params.graph_prefix}.gbz"), file("${params.graph_prefix}.hapl"), file("${params.ref_fasta}.fai"), params.ref_sample, params.platform)
        ch_graph_keyed = BUILD_PERSONAL_GRAPH.out.graph.map { m,g,d,mi,z,p,pm -> [m.pair_id,g,d,mi,z,p,pm] }

        if (params.platform == 'ngs') {
            ch_keyed_reads = ch_reads.map { m,r1,r2 -> [m.pair_id,m,r1,r2] }
            ch_align = ch_keyed_reads.combine(ch_graph_keyed, by: 0).map { key,m,r1,r2,g,d,mi,z,p,pm -> [m,r1,r2,g,d,mi,z,p,pm] }
            NGS_VG_MAP_SURJECT(ch_align)
            NGS_SAMTOOLS_NORMALIZE_SORT(NGS_VG_MAP_SURJECT.out.bam, file("${params.ref_fasta}.fai"))
            NGS_MARK_DUPLICATES(NGS_SAMTOOLS_NORMALIZE_SORT.out.bam)
            NGS_BAM_INDEX(NGS_MARK_DUPLICATES.out.bam)
            ch_all_bam = NGS_BAM_INDEX.out.bam
        } else {
            ch_keyed_reads = ch_reads.map { m,r -> [m.pair_id,m,r] }
            ch_align = ch_keyed_reads.combine(ch_graph_keyed, by: 0).map { key,m,r,g,d,mi,z,p,pm -> [m,r,g,d,mi,z,p,pm] }
            TGS_VG_MAP_SURJECT(ch_align)
            TGS_SAMTOOLS_NORMALIZE_SORT(TGS_VG_MAP_SURJECT.out.bam, file("${params.ref_fasta}.fai"))
            ch_all_bam = TGS_SAMTOOLS_NORMALIZE_SORT.out.bam
        }
    }

    BAM_PREFLIGHT(ch_all_bam, ch_ref)
    ch_validated_bam = BAM_PREFLIGHT.out.bam
    ch_tumor_bam = ch_validated_bam.filter { m,b,i -> m.role == 'tumor' }
    if (params.analysis_mode == 'tumor_normal') ch_normal_bam = ch_validated_bam.filter { m,b,i -> m.role == 'normal' }

    if (params.entry != 'align_only') {
        if (params.analysis_mode == 'tumor_normal') {
            ch_paired = ch_tumor_bam.map {m,b,i->[m.pair_id,m,b,i]}.join(ch_normal_bam.map {m,b,i->[m.pair_id,m,b,i]}).map { key,tm,tb,ti,nm,nb,ni ->
                [[pair_id:key,tumor_id:tm.sample_id,normal_id:nm.sample_id,technology:tm.technology],tb,ti,nb,ni]
            }
        }

        if (params.platform == 'ngs') {
            if (!params.pon || !params.germline) error 'Mutect2 requires pon and germline resources'
            ch_pon = Channel.value([file(params.pon,checkIfExists:true),file("${params.pon}.tbi",checkIfExists:true)])
            ch_germline = Channel.value([file(params.germline,checkIfExists:true),file("${params.germline}.tbi",checkIfExists:true)])
            if (params.analysis_mode == 'tumor_normal') NGS_MUTECT2(ch_paired,ch_ref,ch_pon,ch_germline,ch_interval)
            else NGS_MUTECT2_TUMOR_ONLY(ch_tumor_bam,ch_ref,ch_pon,ch_germline,ch_interval)
        } else {
            if (params.variant_type in ['small','all']) {
                expected_model = params.analysis_mode == 'tumor_normal' \
                    ? (params.longread_technology == 'pacbio' ? 'PACBIO' : 'ONT') \
                    : (params.longread_technology == 'pacbio' ? 'PACBIO_TUMOR_ONLY' : 'ONT_TUMOR_ONLY')
                model = params.deepsomatic_model ?: expected_model
                if (model != expected_model) error "DeepSomatic model ${model} conflicts with technology/mode; expected ${expected_model}"
                if (params.analysis_mode == 'tumor_normal') TGS_DEEPSOMATIC(ch_paired,ch_ref,model)
                else TGS_DEEPSOMATIC_TUMOR_ONLY(ch_tumor_bam,ch_ref,model)
            }
            if (params.variant_type in ['sv','all']) {
                TGS_SNIFFLES2(ch_tumor_bam,ch_ref)
                if (params.analysis_mode == 'tumor_normal') TGS_SNIFFLES2_NORMAL(ch_normal_bam,ch_ref)
            }
        }
    }
}

workflow.onComplete {
    log.info "pan4somatic v${workflow.manifest.version} ${workflow.success ? 'completed' : 'failed'}; results: ${params.outdir}"
}
