process NGS_VG_MAP_SURJECT {
    tag "${meta.pair_id}:${meta.role}"
    label 'process_high'
    container params.container_vg
    publishDir "${params.outdir}/intermediates/ngs_alignment/${meta.pair_id}/${meta.role}", mode: 'copy', pattern: '*.giraffe.gam', enabled: params.publish_gam

    input:
    tuple val(meta), path(fq1), path(fq2), path(personal_gbz), path(personal_dist), path(personal_min), path(personal_zipcodes), path(ref_paths), path(ref_path_map)

    output:
    tuple val(meta), path('pansn.bam'), path('path_map.out.tsv'), emit: bam
    tuple val(meta), path('*.giraffe.gam'), emit: gam

    script:
    """
    cp ${ref_path_map} path_map.out.tsv
    vg giraffe -Z ${personal_gbz} -d ${personal_dist} -m ${personal_min} -z ${personal_zipcodes} \
        -t ${task.cpus} -N ${meta.sample_id} -f ${fq1} -f ${fq2} -p > ${meta.sample_id}.giraffe.gam
    vg surject -x ${personal_gbz} --ref-paths ${ref_paths} -t ${task.cpus} \
        --bam-output --read-length short --sample ${meta.sample_id} --read-group ${meta.sample_id} \
        --prune-low-cplx --interleaved --max-frag-len 3000 \
        ${meta.sample_id}.giraffe.gam > pansn.bam
    test -s pansn.bam
    """
}

process NGS_SAMTOOLS_NORMALIZE_SORT {
    tag "${meta.pair_id}:${meta.role}"
    label 'process_high'
    container params.container_samtools

    input:
    tuple val(meta), path(pansn_bam), path(ref_path_map)
    path ref_fai

    output:
    tuple val(meta), path('sorted.bam'), emit: bam

    script:
    """
    samtools view -H ${pansn_bam} | awk -F'\t' -v OFS='\t' '
        NR==FNR {rename[\$1]=\$2; next}
        \$1=="@SQ" {for(i=1;i<=NF;i++) if(\$i ~ /^SN:/){name=substr(\$i,4); if(name in rename) \$i="SN:" rename[name]}}
        {print}
    ' ${ref_path_map} - > renamed.header.sam

    awk -F'\t' 'BEGIN{OFS="\t"}
        \$1=="@SQ" {
            sn=""; ln=""
            for(i=1;i<=NF;i++) {
                if(\$i~/^SN:/){sn=substr(\$i,4)}
                if(\$i~/^LN:/){ln=substr(\$i,4)}
            }
            if(sn=="" || ln=="" || ++seen[sn]>1) exit 1
            print sn,ln
        }
    ' renamed.header.sam > graph.contigs.tsv

    awk -F'\t' 'BEGIN{OFS="\t"}
        NR==FNR {observed[\$1]=\$2; next}
        \$1 in observed {
            if(observed[\$1] != \$2) {
                printf "ERROR: graph/FASTA length mismatch for %s: graph=%s FASTA=%s\\n", \$1, observed[\$1], \$2 > "/dev/stderr"
                bad=1
            }
            next
        }
        {print "@SQ","SN:"\$1,"LN:"\$2}
        END {exit bad}
    ' graph.contigs.tsv ${ref_fai} > missing.reference.sq.sam

    {
        awk -F'\t' '\$1=="@HD"' renamed.header.sam
        awk -F'\t' '\$1=="@SQ"' renamed.header.sam
        cat missing.reference.sq.sam
        awk -F'\t' '\$1!="@HD" && \$1!="@SQ"' renamed.header.sam
    } > linear.header.sam

    samtools reheader linear.header.sam ${pansn_bam} > raw.bam
    samtools view -H raw.bam | awk -F'\t' 'BEGIN{OFS="\t"} \$1=="@SQ" {sn="";ln="";for(i=1;i<=NF;i++){if(\$i~/^SN:/)sn=substr(\$i,4);if(\$i~/^LN:/)ln=substr(\$i,4)};print sn,ln}' | sort -k1,1 > bam.contigs.tsv
    awk 'BEGIN{OFS="\t"}{print \$1,\$2}' ${ref_fai} | sort -k1,1 > ref.contigs.tsv
    diff -u ref.contigs.tsv bam.contigs.tsv
    samtools addreplacerg -@ ${task.cpus} -w -m overwrite_all \
        -r 'ID:${meta.sample_id}' -r 'SM:${meta.sample_id}' -r 'LB:lib1' \
        -r 'PL:ILLUMINA' -r 'PU:unit1' -o readgroups.bam raw.bam
    samtools sort -@ ${task.cpus} readgroups.bam -o sorted.bam
    samtools quickcheck -v sorted.bam
    """
}

process NGS_MARK_DUPLICATES {
    tag "${meta.pair_id}:${meta.role}"
    label 'process_high'
    container params.container_picard
    publishDir "${params.outdir}/intermediates/ngs_alignment/${meta.pair_id}/${meta.role}", mode: 'copy', pattern: '*.markdup.txt'

    input:
    tuple val(meta), path(sorted_bam)

    output:
    tuple val(meta), path('markdup.bam'), emit: bam

    script:
    """
    gatk MarkDuplicates -I ${sorted_bam} -O markdup.bam \
        -M ${meta.sample_id}.markdup.txt --REMOVE_DUPLICATES false --CREATE_INDEX false
    test -s markdup.bam
    """
}

process NGS_BAM_INDEX {
    tag "${meta.pair_id}:${meta.role}"
    label 'process_low'
    container params.container_samtools
    publishDir "${params.outdir}/intermediates/ngs_alignment/${meta.pair_id}/${meta.role}", mode: 'copy', pattern: '*.{dedup.bam,dedup.bam.bai}'

    input:
    tuple val(meta), path(dedup_bam)

    output:
    tuple val(meta), path('*.dedup.bam'), path('*.dedup.bam.bai'), emit: bam

    script:
    """
    cp ${dedup_bam} ${meta.sample_id}.dedup.bam
    samtools index -@ ${task.cpus} ${meta.sample_id}.dedup.bam
    samtools quickcheck -v ${meta.sample_id}.dedup.bam
    """
}
