process NGS_MUTECT2 {
    tag "${meta.pair_id}"
    label 'process_mutect2'
    container params.container_mutect2
    publishDir "${params.outdir}/variants/ngs_mutect2/${meta.pair_id}", mode: 'copy'

    input:
    tuple val(meta), path(tumor_bam), path(tumor_bai), path(normal_bam), path(normal_bai)
    path ref_files
    path pon_files
    path germline_files
    tuple val(interval_arg), path(interval_files)

    output:
    tuple val(meta), path('*.filtered.vcf.gz'), path('*.filtered.vcf.gz.tbi'), emit: vcf
    tuple val(meta), path('*.metrics.tsv'), path('resource_compatibility.txt'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    def pon = pon_files[0]
    def germline_resource = germline_files[0]
    def interval = interval_arg ? interval_arg.tokenize(',').collect { "-L ${it}" }.join(' ') : ''
    """
    check_vcf_contigs() {
        gzip -cd "\$1" | awk -v fai='${ref_fasta}.fai' -v label="\$2" '
            BEGIN{while((getline < fai)>0) ref[\$1]=\$2; close(fai); bad=0}
            /^##contig=<ID=/ {line=\$0; sub(/^##contig=<ID=/,"",line); split(line,a,","); id=a[1];
                if(!(id in ref)){print "ERROR: " label " contig absent from FASTA: " id > "/dev/stderr"; bad=1}
                if(match(\$0,/length=[0-9]+/)){l=substr(\$0,RSTART+7,RLENGTH-7)+0;if((id in ref)&&ref[id]+0!=l){print "ERROR: " label " length mismatch for " id > "/dev/stderr";bad=1}}}
            END{exit bad}'
    }
    check_vcf_contigs ${pon} PoN
    check_vcf_contigs ${germline_resource} germline_resource
    echo -e 'status\tPASS\nreference\t${ref_fasta}\npon\t${pon}\ngermline\t${germline_resource}\ninterval\t${interval_arg ?: "WHOLE_GENOME"}' > resource_compatibility.txt

    gatk Mutect2 -R ${ref_fasta} -I ${tumor_bam} -tumor ${meta.tumor_id} \
        -I ${normal_bam} -normal ${meta.normal_id} \
        --panel-of-normals ${pon} --germline-resource ${germline_resource} ${interval} \
        --native-pair-hmm-threads ${task.cpus} \
        --f1r2-tar-gz ${meta.pair_id}.f1r2.tar.gz -O ${meta.pair_id}.unfiltered.vcf.gz
    gatk LearnReadOrientationModel -I ${meta.pair_id}.f1r2.tar.gz \
        -O ${meta.pair_id}.orientation.tar.gz
    gatk GetPileupSummaries -I ${tumor_bam} -V ${germline_resource} ${interval} \
        -O tumor.pileups.table
    gatk GetPileupSummaries -I ${normal_bam} -V ${germline_resource} ${interval} \
        -O normal.pileups.table
    gatk CalculateContamination -I tumor.pileups.table -matched normal.pileups.table \
        -O contamination.table --tumor-segmentation segments.table
    gatk FilterMutectCalls -R ${ref_fasta} -V ${meta.pair_id}.unfiltered.vcf.gz \
        --contamination-table contamination.table --tumor-segmentation segments.table \
        --orientation-bias-artifact-priors ${meta.pair_id}.orientation.tar.gz \
        -O ${meta.pair_id}.filtered.vcf.gz
    total=\$(gzip -cd ${meta.pair_id}.filtered.vcf.gz | awk '!/^#/ {n++} END{print n+0}')
    pass=\$(gzip -cd ${meta.pair_id}.filtered.vcf.gz | awk '!/^#/ && \$7=="PASS" {n++} END{print n+0}')
    echo -e 'pair_id\ttotal_records\tpass_records\n${meta.pair_id}\t'"\${total}"'\t'"\${pass}" > ${meta.pair_id}.metrics.tsv
    """
}

process NGS_MUTECT2_TUMOR_ONLY {
    tag "${meta.pair_id}"
    label 'process_mutect2'
    container params.container_mutect2
    publishDir "${params.outdir}/variants/ngs_mutect2/${meta.pair_id}", mode: 'copy'

    input:
    tuple val(meta), path(tumor_bam), path(tumor_bai)
    path ref_files
    path pon_files
    path germline_files
    tuple val(interval_arg), path(interval_files)

    output:
    tuple val(meta), path('*.filtered.vcf.gz'), path('*.filtered.vcf.gz.tbi'), emit: vcf
    tuple val(meta), path('*.metrics.tsv'), path('resource_compatibility.txt'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    def pon = pon_files[0]
    def germline_resource = germline_files[0]
    def interval = interval_arg ? interval_arg.tokenize(',').collect { "-L ${it}" }.join(' ') : ''
    """
    check_vcf_contigs() {
        gzip -cd "\$1" | awk -v fai='${ref_fasta}.fai' -v label="\$2" '
            BEGIN{while((getline < fai)>0) ref[\$1]=\$2; close(fai); bad=0}
            /^##contig=<ID=/ {line=\$0; sub(/^##contig=<ID=/,"",line); split(line,a,","); id=a[1];
                if(!(id in ref)){print "ERROR: " label " contig absent from FASTA: " id > "/dev/stderr"; bad=1}
                if(match(\$0,/length=[0-9]+/)){l=substr(\$0,RSTART+7,RLENGTH-7)+0;if((id in ref)&&ref[id]+0!=l){print "ERROR: " label " length mismatch for " id > "/dev/stderr";bad=1}}}
            END{exit bad}'
    }
    check_vcf_contigs ${pon} PoN
    check_vcf_contigs ${germline_resource} germline_resource
    echo -e 'status\tPASS\nreference\t${ref_fasta}\npon\t${pon}\ngermline\t${germline_resource}\ninterval\t${interval_arg ?: "WHOLE_GENOME"}' > resource_compatibility.txt

    gatk Mutect2 -R ${ref_fasta} -I ${tumor_bam} -tumor ${meta.sample_id} \
        --panel-of-normals ${pon} --germline-resource ${germline_resource} ${interval} \
        --native-pair-hmm-threads ${task.cpus} \
        --f1r2-tar-gz ${meta.pair_id}.f1r2.tar.gz -O ${meta.pair_id}.unfiltered.vcf.gz
    gatk LearnReadOrientationModel -I ${meta.pair_id}.f1r2.tar.gz -O orientation.tar.gz
    gatk GetPileupSummaries -I ${tumor_bam} -V ${germline_resource} ${interval} -O pileups.table
    gatk CalculateContamination -I pileups.table -O contamination.table
    gatk FilterMutectCalls -R ${ref_fasta} -V ${meta.pair_id}.unfiltered.vcf.gz \
        --contamination-table contamination.table --orientation-bias-artifact-priors orientation.tar.gz \
        -O ${meta.pair_id}.filtered.vcf.gz
    total=\$(gzip -cd ${meta.pair_id}.filtered.vcf.gz | awk '!/^#/ {n++} END{print n+0}')
    pass=\$(gzip -cd ${meta.pair_id}.filtered.vcf.gz | awk '!/^#/ && \$7=="PASS" {n++} END{print n+0}')
    echo -e 'pair_id\ttotal_records\tpass_records\n${meta.pair_id}\t'"\${total}"'\t'"\${pass}" > ${meta.pair_id}.metrics.tsv
    """
}
