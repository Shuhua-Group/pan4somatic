process COUNT_KMERS {
    tag "${meta.pair_id}:${meta.graph_source}"
    label 'process_graph'
    container params.container_kmc
    publishDir "${params.outdir}/qc/graph/${meta.pair_id}", mode: 'copy', pattern: 'graph_source_coverage.tsv'

    input:
    tuple val(meta), path(reads)
    path ref_fai

    output:
    tuple val(meta), path('personal_kmc.kff'), emit: kmers
    tuple val(meta), path('graph_source_coverage.tsv'), emit: qc

    script:
    def inputs = reads.collect { it.toString() }.join('\n')
    """
    printf '%s\n' '${inputs}' > kmc.inputs
    : > read_bases.txt
    while IFS= read -r reads_file; do
        case "\${reads_file}" in
            *.gz) gzip -cd "\${reads_file}" ;;
            *) cat "\${reads_file}" ;;
        esac | awk 'NR % 4 == 2 {n += length(\$0)} END {print n + 0}' >> read_bases.txt
    done < kmc.inputs
    total_read_bases=\$(awk '{n+=\$1} END{print n+0}' read_bases.txt)
    reference_bases=\$(awk '{n+=\$2} END{print n+0}' ${ref_fai})
    estimated_coverage=\$(awk -v r="\${total_read_bases}" -v g="\${reference_bases}" 'BEGIN{if(g>0) printf "%.3f",r/g; else print "NA"}')
    {
        echo -e 'pair_id\tgraph_source\ttotal_read_bases\treference_bases\testimated_raw_coverage\tminimum_requested'
        echo -e '${meta.pair_id}\t${meta.graph_source}\t'"\${total_read_bases}"'\t'"\${reference_bases}"'\t'"\${estimated_coverage}"'\t${params.min_graph_source_coverage}'
    } > graph_source_coverage.tsv
    awk -v c="\${estimated_coverage}" -v m='${params.min_graph_source_coverage}' 'BEGIN{if(c+0 < m+0){printf "ERROR: estimated graph-source coverage %.3fx is below required %.3fx\\n",c,m > "/dev/stderr"; exit 1}}'

    kmc -k29 -m${params.kmc_memory_gb} -okff -t${task.cpus} @kmc.inputs personal_kmc .
    test -s personal_kmc.kff
    """
}

process BUILD_PERSONAL_GRAPH {
    tag "${meta.pair_id}:${meta.graph_source}"
    label 'process_graph'
    container params.container_vg
    publishDir "${params.outdir}/qc/graph/${meta.pair_id}", mode: 'copy', pattern: 'reference_path_audit.tsv'

    input:
    tuple val(meta), path(kff)
    path base_gbz
    path base_hapl
    path ref_fai
    val ref_sample
    val platform

    output:
    tuple val(meta), path('personal.gbz'), path('personal.dist'), path('personal.min'), path('personal.zipcodes'), path('reference.paths.txt'), path('reference_path_map.tsv'), emit: graph
    path('reference_path_audit.tsv'), emit: audit

    script:
    def index_cmd = platform == 'tgs' ? """
    # Build the long-read indexes sequentially.  `vg autoindex` may construct
    # multiple indexes concurrently and exceeded the Slurm cgroup limit on a
    # whole-genome personalized graph.  Temporary names prevent partial files
    # from being exposed as valid outputs after an interrupted build.
    vg index -t ${task.cpus} -j personal.dist.tmp personal.gbz
    test -s personal.dist.tmp
    mv personal.dist.tmp personal.dist

    vg minimizer -t ${task.cpus} -k 31 -w 50 -W --save-memory \
        -d personal.dist \
        -o personal.longread.withzip.min.tmp \
        -z personal.longread.zipcodes.tmp \
        personal.gbz
    test -s personal.longread.withzip.min.tmp
    test -s personal.longread.zipcodes.tmp
    mv personal.longread.withzip.min.tmp personal.min
    mv personal.longread.zipcodes.tmp personal.zipcodes
    """ : """
    vg index -t ${task.cpus} -j personal.dist personal.gbz
    vg minimizer -t ${task.cpus} -d personal.dist -o personal.min -z personal.zipcodes personal.gbz
    """
    """
    vg haplotypes -v 2 -t ${task.cpus} \
        -i ${base_hapl} \
        -k ${kff} \
        --include-reference --diploid-sampling \
        -g personal.gbz \
        ${base_gbz}

    ${index_cmd}
    chmod a-w personal.dist

    vg paths -L -x personal.gbz > all.graph.paths.txt
    awk 'NF {print \$1}' ${ref_fai} > reference.contigs.txt
    if [ ! -s reference.contigs.txt ]; then
        echo "ERROR: no contigs found in ${ref_fai}" >&2
        exit 1
    fi

    : > reference.paths.txt
    : > reference_path_map.tsv
    printf 'fasta_contig\tstatus\tgraph_path\n' > reference_path_audit.tsv
    while IFS= read -r contig; do
        preferred='${ref_sample}#0#'"\${contig}"
        selected=''
        if grep -Fqx "\${preferred}" all.graph.paths.txt; then
            selected="\${preferred}"
        elif grep -Fqx "\${contig}" all.graph.paths.txt; then
            selected="\${contig}"
        else
            matches=\$(awk -v suffix="#\${contig}" 'substr(\$0,length(\$0)-length(suffix)+1)==suffix {print}' all.graph.paths.txt)
            match_count=\$(printf '%s\n' "\${matches}" | awk 'NF{n++} END{print n+0}')
            [ "\${match_count}" -eq 1 ] && selected="\${matches}"
        fi
        if [ -n "\${selected}" ]; then
            printf '%s\n' "\${selected}" >> reference.paths.txt
            printf '%s\t%s\n' "\${selected}" "\${contig}" >> reference_path_map.tsv
            printf '%s\tselected\t%s\n' "\${contig}" "\${selected}" >> reference_path_audit.tsv
        else
            printf '%s\tabsent_from_graph\t.\n' "\${contig}" >> reference_path_audit.tsv
        fi
    done < reference.contigs.txt

    selected_count=\$(wc -l < reference.paths.txt)
    fasta_count=\$(wc -l < reference.contigs.txt)
    missing_count=\$((fasta_count - selected_count))
    [ "\${selected_count}" -gt 0 ] || {
        echo 'ERROR: no FASTA contig has an unambiguous reference path in the personalized graph' >&2
        exit 1
    }
    echo "REFERENCE_PATHS_SELECTED=\${selected_count}"
    echo "REFERENCE_CONTIGS_ABSENT_FROM_GRAPH=\${missing_count}"
    if [ "\${missing_count}" -gt 0 ]; then
        echo "WARNING: \${missing_count} FASTA contigs are absent from the graph; they will be appended to the BAM header with no graph-derived alignments" >&2
    fi
    """
}
