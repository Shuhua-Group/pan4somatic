process BAM_PREFLIGHT {
    tag "${meta.pair_id}:${meta.role}"
    label 'process_low'
    container params.container_samtools

    publishDir "${params.outdir}/qc/bam/${meta.pair_id}/${meta.role}",
        mode: 'copy', pattern: '*.{flagstat.txt,stats.txt,coverage.tsv,preflight.txt}'

    input:
    tuple val(meta), path(input_bam), path(input_bai)
    path ref_files

    output:
    tuple val(meta), path("${meta.sample_id}.validated.bam"), path("${meta.sample_id}.validated.bam.bai"), emit: bam
    tuple val(meta), path('*.preflight.txt'), path('*.flagstat.txt'), path('*.stats.txt'), path('*.coverage.tsv'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    """
    set -euo pipefail
    samtools quickcheck -v ${input_bam}

    sort_order=\$(samtools view -H ${input_bam} | awk -F'\\t' '\$1=="@HD" {for(i=1;i<=NF;i++) if(\$i ~ /^SO:/){sub(/^SO:/,"",\$i); print \$i; exit}}')
    [ "\${sort_order}" = coordinate ] || { echo "ERROR: BAM is not coordinate sorted (SO=\${sort_order:-missing})" >&2; exit 1; }

    observed_sm=\$(samtools view -H ${input_bam} | awk -F'\\t' '\$1=="@RG" {for(i=1;i<=NF;i++) if(\$i ~ /^SM:/){sub(/^SM:/,"",\$i); print \$i}}' | sort -u)
    [ "\${observed_sm}" = '${meta.sample_id}' ] || {
        echo "ERROR: expected exactly one BAM SM='${meta.sample_id}', observed: \${observed_sm:-none}" >&2
        exit 1
    }

    samtools view -H ${input_bam} | awk -F'\\t' 'BEGIN{OFS="\\t"} \$1=="@SQ" {sn="";ln="";for(i=1;i<=NF;i++){if(\$i~/^SN:/){sn=\$i;sub(/^SN:/,"",sn)};if(\$i~/^LN:/){ln=\$i;sub(/^LN:/,"",ln)}};print sn,ln}' | sort -k1,1 > bam.contigs.tsv
    awk 'BEGIN{OFS="\\t"}{print \$1,\$2}' ${ref_fasta}.fai | sort -k1,1 > ref.contigs.tsv
    diff -u ref.contigs.tsv bam.contigs.tsv > contig.diff || {
        echo 'ERROR: BAM @SQ names/lengths differ from the reference FASTA index:' >&2
        head -80 contig.diff >&2
        exit 1
    }

    cp ${input_bam} ${meta.sample_id}.validated.bam
    cp ${input_bai} ${meta.sample_id}.validated.bam.bai
    samtools flagstat -@ ${task.cpus} ${input_bam} > ${meta.sample_id}.flagstat.txt
    samtools stats -@ ${task.cpus} ${input_bam} > ${meta.sample_id}.stats.txt
    samtools coverage ${input_bam} > ${meta.sample_id}.coverage.tsv
    {
        echo -e 'pair_id\\t${meta.pair_id}'
        echo -e 'sample_id\\t${meta.sample_id}'
        echo -e 'role\\t${meta.role}'
        echo -e 'sort_order\\tcoordinate'
        echo -e 'read_group_sm\\t${meta.sample_id}'
        echo -e 'reference_contigs\\t'\$(wc -l < ref.contigs.tsv)
        echo -e 'status\\tPASS'
    } > ${meta.sample_id}.preflight.txt
    """
}
