process TGS_VG_MAP_SURJECT {
    tag "${meta.pair_id}:${meta.role}:${meta.technology}"
    label 'process_high'
    container params.container_vg
    publishDir "${params.outdir}/intermediates/tgs_alignment/${meta.pair_id}/${meta.role}", mode: 'copy', pattern: '*.giraffe.gam', enabled: params.publish_gam

    input:
    tuple val(meta), path(fastq), path(personal_gbz), path(personal_dist), path(personal_min), path(personal_zipcodes), path(ref_paths), path(ref_path_map)

    output:
    tuple val(meta), path('pansn.bam'), path('path_map.out.tsv'), emit: bam
    tuple val(meta), path('*.giraffe.gam'), emit: gam

    script:
    def preset = meta.technology == 'pacbio' ? '--parameter-preset hifi' : '--parameter-preset r10'
    """
    cp ${ref_path_map} path_map.out.tsv
    vg giraffe -p -t ${task.cpus} ${preset} \
        -Z ${personal_gbz} -d ${personal_dist} -m ${personal_min} \
        -z ${personal_zipcodes} -N ${meta.sample_id} -f ${fastq} > ${meta.sample_id}.giraffe.gam
    vg surject -b -x ${personal_gbz} -t ${task.cpus} --sample ${meta.sample_id} --read-group ${meta.sample_id} \
        --read-length long --ref-paths ${ref_paths} ${meta.sample_id}.giraffe.gam > pansn.bam
    test -s pansn.bam
    """
}

process TGS_SAMTOOLS_NORMALIZE_SORT {
    tag "${meta.pair_id}:${meta.role}:${meta.technology}"
    label 'process_high'
    container params.container_samtools
    publishDir "${params.outdir}/intermediates/tgs_alignment/${meta.pair_id}/${meta.role}", mode: 'copy', pattern: '*.{sorted.bam,sorted.bam.bai}'

    input:
    tuple val(meta), path(pansn_bam), path(ref_path_map)
    path ref_fai

    output:
    tuple val(meta), path('*.sorted.bam'), path('*.sorted.bam.bai'), emit: bam

    script:
    def platform = meta.technology == 'pacbio' ? 'PACBIO' : 'ONT'
    """
    samtools view -H ${pansn_bam} | awk -F'\t' -v OFS='\t' '
        NR==FNR {rename[\$1]=\$2; next}
        \$1=="@SQ" {for(i=1;i<=NF;i++) if(\$i ~ /^SN:/){name=substr(\$i,4); if(name in rename) \$i="SN:" rename[name]}}
        {print}
    ' ${ref_path_map} - > renamed.header.sam

    awk -F'\t' 'BEGIN{OFS="\t"}
        \$1=="@SQ" {
            sn=""; ln=""
            for(i=1;i<=NF;i++) {
                if(\$i~/^SN:/){sn=substr(\$i,4)}
                if(\$i~/^LN:/){ln=substr(\$i,4)}
            }
            if(sn=="" || ln=="" || ++seen[sn]>1) exit 1
            print sn,ln
        }
    ' renamed.header.sam > graph.contigs.tsv

    awk -F'\t' 'BEGIN{OFS="\t"}
        NR==FNR {observed[\$1]=\$2; next}
        \$1 in observed {
            if(observed[\$1] != \$2) {
                printf "ERROR: graph/FASTA length mismatch for %s: graph=%s FASTA=%s\\n", \$1, observed[\$1], \$2 > "/dev/stderr"
                bad=1
            }
            next
        }
        {print "@SQ","SN:"\$1,"LN:"\$2}
        END {exit bad}
    ' graph.contigs.tsv ${ref_fai} > missing.reference.sq.sam

    {
        awk -F'\t' '\$1=="@HD"' renamed.header.sam
        awk -F'\t' '\$1=="@SQ"' renamed.header.sam
        cat missing.reference.sq.sam
        awk -F'\t' '\$1!="@HD" && \$1!="@SQ"' renamed.header.sam
    } > linear.header.sam

    samtools reheader linear.header.sam ${pansn_bam} > raw.bam
    samtools view -H raw.bam | awk -F'\t' 'BEGIN{OFS="\t"} \$1=="@SQ" {sn="";ln="";for(i=1;i<=NF;i++){if(\$i~/^SN:/)sn=substr(\$i,4);if(\$i~/^LN:/)ln=substr(\$i,4)};print sn,ln}' | sort -k1,1 > bam.contigs.tsv
    awk 'BEGIN{OFS="\t"}{print \$1,\$2}' ${ref_fai} | sort -k1,1 > ref.contigs.tsv
    diff -u ref.contigs.tsv bam.contigs.tsv
    samtools addreplacerg -@ ${task.cpus} -w -m overwrite_all \
        -r 'ID:${meta.sample_id}' -r 'SM:${meta.sample_id}' -r 'PL:${platform}' \
        -o readgroups.bam raw.bam
    samtools sort -@ ${task.cpus} readgroups.bam -o ${meta.sample_id}.sorted.bam
    samtools index -@ ${task.cpus} ${meta.sample_id}.sorted.bam
    samtools quickcheck -v ${meta.sample_id}.sorted.bam
    """
}
