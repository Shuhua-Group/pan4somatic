process TGS_DEEPSOMATIC {
    tag "${meta.pair_id}"
    label 'process_high'
    container params.container_deepsomatic
    publishDir "${params.outdir}/variants/tgs_deepsomatic/${meta.pair_id}", mode: 'copy'

    input:
    tuple val(meta), path(tumor_bam), path(tumor_bai), path(normal_bam), path(normal_bai)
    path ref_files
    val model

    output:
    tuple val(meta), path('*.vcf.gz'), path('*.vcf.gz.tbi'), emit: vcf
    tuple val(meta), path('*.metrics.tsv'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    """
    mkdir -p intermediate_results logs
    run_deepsomatic --ref=${ref_fasta} --model_type=${model} \
        --reads_tumor=${tumor_bam} --sample_name_tumor=${meta.tumor_id} \
        --reads_normal=${normal_bam} --sample_name_normal=${meta.normal_id} \
        --output_vcf=${meta.pair_id}.deepsomatic.vcf.gz --num_shards=${task.cpus} \
        --logging_dir=logs --intermediate_results_dir=intermediate_results --vcf_stats_report=true
    total=\$(gzip -cd ${meta.pair_id}.deepsomatic.vcf.gz | awk '!/^#/ {n++} END{print n+0}')
    pass=\$(gzip -cd ${meta.pair_id}.deepsomatic.vcf.gz | awk '!/^#/ && \$7=="PASS" {n++} END{print n+0}')
    echo -e 'pair_id\ttotal_records\tpass_records\n${meta.pair_id}\t'"\${total}"'\t'"\${pass}" > ${meta.pair_id}.metrics.tsv
    """
}

process TGS_DEEPSOMATIC_TUMOR_ONLY {
    tag "${meta.pair_id}"
    label 'process_high'
    container params.container_deepsomatic
    publishDir "${params.outdir}/variants/tgs_deepsomatic/${meta.pair_id}", mode: 'copy'

    input:
    tuple val(meta), path(tumor_bam), path(tumor_bai)
    path ref_files
    val model

    output:
    tuple val(meta), path('*.vcf.gz'), path('*.vcf.gz.tbi'), emit: vcf
    tuple val(meta), path('*.metrics.tsv'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    def pon_flag = params.deepsomatic_use_default_pon_filtering ? '--use_default_pon_filtering=true' : '--use_default_pon_filtering=false'
    """
    mkdir -p intermediate_results logs
    run_deepsomatic --ref=${ref_fasta} --model_type=${model} \
        --reads_tumor=${tumor_bam} --sample_name_tumor=${meta.sample_id} \
        --output_vcf=${meta.pair_id}.deepsomatic.vcf.gz --num_shards=${task.cpus} \
        --logging_dir=logs --intermediate_results_dir=intermediate_results --vcf_stats_report=true \
        ${pon_flag}
    total=\$(gzip -cd ${meta.pair_id}.deepsomatic.vcf.gz | awk '!/^#/ {n++} END{print n+0}')
    pass=\$(gzip -cd ${meta.pair_id}.deepsomatic.vcf.gz | awk '!/^#/ && \$7=="PASS" {n++} END{print n+0}')
    echo -e 'pair_id\ttotal_records\tpass_records\n${meta.pair_id}\t'"\${total}"'\t'"\${pass}" > ${meta.pair_id}.metrics.tsv
    """
}
