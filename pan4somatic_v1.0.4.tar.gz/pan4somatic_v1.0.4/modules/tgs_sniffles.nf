process TGS_SNIFFLES2 {
    tag "${meta.pair_id}"
    label 'process_medium'
    container params.container_sniffles
    publishDir "${params.outdir}/variants/tgs_sv_sniffles2/${meta.pair_id}", mode: 'copy'

    input:
    tuple val(meta), path(tumor_bam), path(tumor_bai)
    path ref_files

    output:
    tuple val(meta), path('*.tumor.mosaic.vcf.gz'), path('*.tumor.snf'), emit: tumor
    tuple val(meta), path('*.tumor.metrics.tsv'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    """
    sniffles --input ${tumor_bam} --reference ${ref_fasta} --threads ${task.cpus} \
        --mosaic --vcf ${meta.pair_id}.tumor.mosaic.vcf.gz --snf ${meta.pair_id}.tumor.snf
    total=\$(gzip -cd ${meta.pair_id}.tumor.mosaic.vcf.gz | awk '!/^#/ {n++} END{print n+0}')
    pass=\$(gzip -cd ${meta.pair_id}.tumor.mosaic.vcf.gz | awk '!/^#/ && \$7=="PASS" {n++} END{print n+0}')
    echo -e 'pair_id\trole\ttotal_records\tpass_records\n${meta.pair_id}\ttumor\t'"\${total}"'\t'"\${pass}" > ${meta.pair_id}.tumor.metrics.tsv
    """
}

process TGS_SNIFFLES2_NORMAL {
    tag "${meta.pair_id}:normal"
    label 'process_medium'
    container params.container_sniffles
    publishDir "${params.outdir}/variants/tgs_sv_sniffles2/${meta.pair_id}", mode: 'copy'

    input:
    tuple val(meta), path(normal_bam), path(normal_bai)
    path ref_files

    output:
    tuple val(meta), path('*.normal.vcf.gz'), path('*.normal.snf'), emit: normal
    tuple val(meta), path('*.normal.metrics.tsv'), emit: qc

    script:
    def ref_fasta = ref_files.find { !it.name.endsWith('.fai') && !it.name.endsWith('.dict') }
    """
    sniffles --input ${normal_bam} --reference ${ref_fasta} --threads ${task.cpus} \
        --vcf ${meta.pair_id}.normal.vcf.gz --snf ${meta.pair_id}.normal.snf
    total=\$(gzip -cd ${meta.pair_id}.normal.vcf.gz | awk '!/^#/ {n++} END{print n+0}')
    pass=\$(gzip -cd ${meta.pair_id}.normal.vcf.gz | awk '!/^#/ && \$7=="PASS" {n++} END{print n+0}')
    echo -e 'pair_id\trole\ttotal_records\tpass_records\n${meta.pair_id}\tnormal\t'"\${total}"'\t'"\${pass}" > ${meta.pair_id}.normal.metrics.tsv
    """
}
