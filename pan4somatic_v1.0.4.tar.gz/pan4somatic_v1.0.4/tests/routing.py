#!/usr/bin/env python3
"""Run the actual workflow/config with mocked tool bodies, not bioinformatics callers.

Checks sample routing, graph-source role, caller selection and BAM-entry bypass.
The process interfaces are retained; mocks only create declared output files.
Run: python3 tests/routing.py [source-directory]
"""
import csv
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter

source = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
nextflow = os.environ.get('NEXTFLOW', 'nextflow')
with tempfile.TemporaryDirectory(prefix='pan4somatic-routing-') as temporary:
    root = Path(temporary)
    project = root / 'pipeline'
    shutil.copytree(source, project)
    for module in (project / 'modules').glob('*.nf'):
        mocked = []
        for block in re.split(r'(?=^process )', module.read_text(), flags=re.M):
            if not block.strip():
                continue
            interface = block.split('    script:', 1)[0]
            output = interface.split('    output:', 1)[1]
            paths = re.findall(r'''path\(['"](.*?)['"]\)''', output)
            files = sorted({p.replace('*', 'mock') for p in paths})
            commands = '\n'.join(f'    touch "{p}"' for p in files)
            mocked.append(interface + '    script:\n    """\n' + commands + '\n    """\n}\n')
        module.write_text('\n'.join(mocked))
    data = root / 'inputs'
    data.mkdir()
    for name in ['ref.fa', 'ref.fa.fai', 'ref.dict', 'graph.gbz', 'graph.hapl',
                 'pon.vcf.gz', 'pon.vcf.gz.tbi', 'germline.vcf.gz', 'germline.vcf.gz.tbi',
                 'tumor.R1.fq', 'tumor.R2.fq', 'normal.R1.fq', 'normal.R2.fq',
                 'tumor.bam', 'tumor.bam.bai', 'normal.bam', 'normal.bam.bai']:
        (data / name).touch()
    config = root / 'test.config'
    config.write_text('''process {
    executor = 'local'
    withLabel: /process_.*/ {
        cpus = 1
        memory = '128 MB'
        time = '1 min'
    }
}
report.enabled = false
timeline.enabled = false
trace.fields = 'process,tag,status'
''')
    cases = [(platform, entry, paired) for platform in ['ngs', 'tgs']
             for entry in ['full', 'align_only', 'call_from_bam'] for paired in [False, True]]
    for platform, entry, paired in cases:
        label = f'{platform}-{entry}-{"paired" if paired else "tumor"}'
        run = root / label
        run.mkdir()
        trace = run / 'trace.tsv'
        args = [nextflow, '-log', str(run / 'nextflow.log'), 'run', str(project / 'main.nf'),
                '-c', str(config), '-ansi-log', 'false', '-with-trace', str(trace),
                '--platform', platform, '--entry', entry,
                '--analysis_mode', 'tumor_normal' if paired else 'tumor_only',
                '--variant_type', 'small' if platform == 'ngs' else 'all',
                '--ref_fasta', str(data / 'ref.fa'), '--outdir', str(run / 'results')]
        if entry == 'call_from_bam':
            args += ['--tumor_bam', str(data / 'tumor.bam')]
            if paired:
                args += ['--normal_bam', str(data / 'normal.bam')]
        else:
            args += ['--graph_prefix', str(data / 'graph')]
            for role in (['tumor', 'normal'] if paired else ['tumor']):
                reads = str(data / f'{role}.R1.fq')
                if platform == 'ngs':
                    reads += ',' + str(data / f'{role}.R2.fq')
                args += [f'--{role}_fastq', reads]
        if platform == 'ngs' and entry != 'align_only':
            args += ['--pon', str(data / 'pon.vcf.gz'), '--germline', str(data / 'germline.vcf.gz')]
        result = subprocess.run(args, cwd=run, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if result.returncode:
            raise AssertionError(f'{label}: Nextflow failed\n{result.stdout}')
        with trace.open() as handle:
            rows = list(csv.DictReader(handle, delimiter='\t'))
        assert all(row['status'] == 'COMPLETED' for row in rows), (label, rows)
        counts = Counter(row['process'] for row in rows)
        n = 2 if paired else 1
        expected = Counter({'BAM_PREFLIGHT': n})
        if entry != 'call_from_bam':
            expected.update({'COUNT_KMERS': 1, 'BUILD_PERSONAL_GRAPH': 1})
            alignment = ['NGS_VG_MAP_SURJECT', 'NGS_SAMTOOLS_NORMALIZE_SORT', 'NGS_MARK_DUPLICATES', 'NGS_BAM_INDEX'] if platform == 'ngs' else ['TGS_VG_MAP_SURJECT', 'TGS_SAMTOOLS_NORMALIZE_SORT']
            expected.update({name: n for name in alignment})
            graph_tags = [row['tag'] for row in rows if row['process'] in ['COUNT_KMERS', 'BUILD_PERSONAL_GRAPH']]
            assert graph_tags == ['pair1:normal' if paired else 'pair1:tumor'] * 2, (label, graph_tags)
        if entry != 'align_only':
            if platform == 'ngs':
                expected['NGS_MUTECT2' if paired else 'NGS_MUTECT2_TUMOR_ONLY'] = 1
            else:
                expected['TGS_DEEPSOMATIC' if paired else 'TGS_DEEPSOMATIC_TUMOR_ONLY'] = 1
                expected['TGS_SNIFFLES2'] = 1
                if paired:
                    expected['TGS_SNIFFLES2_NORMAL'] = 1
        assert counts == expected, f'{label}: expected {dict(expected)}, observed {dict(counts)}'
        roles = {row['tag'] for row in rows if row['process'] == 'BAM_PREFLIGHT'}
        assert roles == ({'pair1:tumor', 'pair1:normal'} if paired else {'pair1:tumor'}), (label, roles)
        print(f'PASS {label}: {sum(counts.values())} tasks', flush=True)
print('PASS all 12 routing cases; bioinformatics tool bodies were mocked.')
