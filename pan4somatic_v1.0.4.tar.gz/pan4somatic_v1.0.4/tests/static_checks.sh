#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
bash -n pan4somatic tests/static_checks.sh
python3 -m json.tool nextflow_schema.json >/dev/null
./pan4somatic --version
./pan4somatic --help >/dev/null
echo 'static checks: PASS'
